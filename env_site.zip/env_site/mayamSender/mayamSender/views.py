from django.http import HttpResponse
from django.shortcuts import render
import os

def homepage (request):
    return HttpResponse("Homepage")

def form (request):
    #form = TransactionForm()
    # return HttpResponse("homepage")
    print(request.POST)
    return render(request, os.path.join('form.html'))