import os

# Download du dossier
os.system('cmd /k "https://drive.google.com/drive/folders/1PJebbuSt7GiEZNZDGxJDHjmhkN_vxIBT?usp=sharing"')
https://drive.google.com/uc?export=download&id=1PJebbuSt7GiEZNZDGxJDHjmhkN_vxIBT
# Lancer la console & écrire py manage.py runserver
os.system('cmd /k "py manage.py runserver"')

# Lancer une page web à l'adresse http://127.0.0.1:8000/form/
os.system('cmd /c "explorer http://127.0.0.1:8000/form/"')